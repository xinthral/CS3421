# Computer Organization
> CS3421 { Aug - Dec 2021 } The purpose of this was to emulate a system
utilizing concepts of System Clocks, CPU Registries, and Memory Banks

## Clock
* dump
* reset
* tick

## CPU
* dump
* reset
* set reg

## Memory
* create
* dump
* reset
* set
