#ifndef TEST_H
#define TEST_H

#include "clock.h"
#include "cpu.h"
#include "memory.h"
#include "utilities.h"
#include <stdio.h>


#endif
