It has been while since I've used C/C++, and it felt good to get back into this.
There was a bunch of things I struggled to understand or get working.
A few things I struggled with:
* I was using the wrong compiler
* Converting c++11+ basic_string to be printable with printf
* How to do proper linking with makefiles
* Getting down a solid method of testing functions
* The singleton methods don't respond the way I had expected
* When I call my fetch_memory directly it works fine, but for some reason the
it's getting generated, the call just doesn't work so it fetches things out
the index of memory, usually garbage values....idk
* Couldn't get the memory to work right in general. This whole thing needs
rewriting.
* After some time of struggling, and being late on Assignment, I finally got The
memory working. There was a logic error and an OBE that I failed to see.
* Just grasping the conditions under which the instructions are asking for
things to be setup felt ambiguous. You mentioned this was part of the exercise,
but it still was frustrating.
* *********************** *
* The entropy part of the assignment has me confused, as this wasn't mentioned
anywhere else in the assignment. This was an erroneous detail.
* I have been trying to make myself do conversions from hex to decimal or
visa-versa, but I still feel unprepared for the exam.
* I tried to create my imemory class by inheriting it from memory class and
overloading some of the methods but that felt like it needed decoupling.
* *********************** *
* Just understanding the instructions is the hardest part out of this assignment,
which shouldn't be the case.
* While talking to Tony on Saturday I realized I had to rewrite all this, which
I was able to get working for the first part, and while implementing the next
assignemnt details I fell behind.
* The storage and load words dont' work completely.
