The caching mechanism doesn't seem to be working the way I intended it to, so I
am going to have to rewrite this module.

Everything else works, except the copying of data from memory into cache.
