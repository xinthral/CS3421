It has been while since I've used C/C++, and it felt good to get back into this.
There was a bunch of things I struggled to understand or get working.
A few things I struggled with:
* I was using the wrong compiler
* Converting c++11+ basic_string to be printable with printf
* How to do proper linking with makefiles
* Getting down a solid method of testing functions
* The singleton methods don't respond the way I had expected
* When I call my fetch_memory directly it works fine, but for some reason the
it's getting generated, the call just doesn't work so it fetches things out
the index of memory, usually garbage values....idk
* Couldn't get the memory to work right in general. This whole thing needs
rewriting.
