- I struggled heavily with getting the event loops and timing to work out from
    Assignment 2.
- The branching features are not fully implemented yet. 
