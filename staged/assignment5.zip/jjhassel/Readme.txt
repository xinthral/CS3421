I did what I could with what I could.
